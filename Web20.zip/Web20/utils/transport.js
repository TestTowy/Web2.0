// Serwer poczty przychodzącej: POP3, t.pl STARTTLS
// Serwer poczty wychodzącej: SMTP, t.pl, bez szyfrowania
const nodemailer = require('nodemailer');

let selfSignedConfig = {
    host: 't.pl',
    port: 465,
    secure: true, // użwa TLS
    auth: {
    user: 'web20@t.pl', pass: 'stud234'
    },
    tls: {
    // nie przerywa przy błędnym certyfikacie
    rejectUnauthorized: false
    }
};

let tTransporter = nodemailer.createTransport(selfSignedConfig);
module.exports = { tTransporter: tTransporter };