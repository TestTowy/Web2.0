var mongoose = require('mongoose');
var passport = require('passport');
var sha1 = require('sha1');
LocalStrategy = require('passport-local').Strategy;

mongoose.connect('mongodb://DawidMDB:Test123@ds022228.mlab.com:22228/dawidmdb', { useNewUrlParser: true },function(err) {
    if(err) {
        console.log('błąd połączenia', err);
    } else {
        console.log('połączenie udane');
    }
});

// schemat dokumentu opisującego użytkowników w kolekcji users
var userSchema = new mongoose.Schema({
	username: { type: String, required: true, unique: true},
    password: { type: String, required: true},
    email: { type: String, required: false, unique: true},
    admin: {type: Boolean, default: false},
    active: {type: Boolean, default: false, required: true}
});

userSchema.methods.validPassword = function(pass) {
    return sha1(pass)==this.password;
  };

userSchema.methods.accountActivate = function() {
    return this.active;
};
  
module.exports = mongoose.model('user', userSchema);
